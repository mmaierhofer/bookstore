export class Image {

    constructor (
        public id: number,
        public url: string,
        public title: string
    ) {}
}
