import { Component } from '@angular/core';
import { Book } from './shared/book';

@Component({
  selector: 'bs-root',
  template: '<bs-book-list *ngIf="listOn"></bs-book-list><bs-book-details *ngIf="detailsOn" [book]="book"></bs-book-details>',
  styles: []
})

export class AppComponent {

  listOn = true;
  detailsOn = false;

  book: Book;
}
